const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'ecommerce.db');
const db = new sqlite3.Database(DB_PATH, (err) => {
  if (err) {
    console.error('SQLite connection failed:', err.message);
    process.exit(1);
  }
});

const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
const seed = fs.readFileSync(path.join(__dirname, 'seed.sql'), 'utf8');

db.exec(schema, (err) => {
  if (err) {
    console.error('Schema initialization error:', err.message);
    process.exit(1);
  }

  db.exec(seed, (err) => {
    if (err) {
      console.error('Seeding error:', err.message);
      process.exit(1);
    }
    console.log('Database seeded successfully.');
    db.close();
  });
});

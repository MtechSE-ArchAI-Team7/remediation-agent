INSERT INTO products (name, description, price, inventory) VALUES
  ('Wireless Mouse', 'Ergonomic wireless mouse with USB receiver', 19.99, 50),
  ('Mechanical Keyboard', 'RGB backlit mechanical keyboard', 59.99, 30),
  ('USB-C Hub', '7-in-1 USB-C hub with HDMI and card reader', 29.99, 75),
  ('Noise Cancelling Headphones', 'Over-ear headphones with active noise cancellation', 89.99, 20),
  ('Webcam 1080p', 'Full HD webcam with built-in microphone', 34.99, 40);

INSERT INTO users (username, password, email, is_admin) VALUES
  ('demo', 'demo123', 'demo@example.com', 0),
  ('admin', 'admin123', 'admin@example.com', 1);
